
/* `chub_lab`.`provinces` */
$provinces = array(
  array('id' => '1','name' => 'Kigali Town/Umujyi wa Kigali','country_id' => 'RW','created_at' => '2018-03-22 14:02:27','updated_at' => '2018-03-22 14:02:27'),
  array('id' => '2','name' => 'South/Amajyepfo','country_id' => 'RW','created_at' => '2018-03-22 14:02:27','updated_at' => '2018-03-22 14:02:27'),
  array('id' => '3','name' => 'West/Iburengerazuba','country_id' => 'RW','created_at' => '2018-03-22 14:02:27','updated_at' => '2018-03-22 14:02:27'),
  array('id' => '4','name' => 'North/Amajyaruguru','country_id' => 'RW','created_at' => '2018-03-22 14:02:27','updated_at' => '2018-03-22 14:02:27'),
  array('id' => '5','name' => 'East/Iburasirazuba','country_id' => 'RW','created_at' => '2018-03-22 14:02:27','updated_at' => '2018-03-22 14:02:27')
);
